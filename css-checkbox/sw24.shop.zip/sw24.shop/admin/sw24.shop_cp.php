<?
$css = file_get_contents($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/sw24.shop/css/custom/source.css');

//parse_str($_SERVER['QUERY_STRING'], $arr);
$search = array('##THEME_COLOR##', '##MENU_COLOR##', '##BG_COLOR##', '##MAIN_SLIDE##', '##PAGE_FOOTER##');
$replace = array();

// Colors:
if (empty($_GET['THEME_COLOR']) || empty($_GET['MENU_COLOR']) || empty($_GET['BG_COLOR']))
	$replace = array('#498700', '#d61d29', '#fff');
else
	$replace = array('#'.$_GET['THEME_COLOR'], '#'.$_GET['MENU_COLOR'], '#'.$_GET['BG_COLOR']);

// Slider:
if (empty($_GET['MAIN_SLIDE'])) $replace[] = '100%';
else $replace[] = '1260px';

// Footer:
if (empty($_GET['PAGE_FOOTER'])) $replace[] = '100%';
else $replace[] = '1260px';

$path = $_SERVER["DOCUMENT_ROOT"].'/bitrix/templates/marant/css/theme.css';
$result = str_replace($search, $replace, $css);
file_put_contents($path, $result);

/*
	THEME_COLOR - #498700
	MENU_COLOR  - #d61d29
	BG_COLOR    - #fff
*/
?>