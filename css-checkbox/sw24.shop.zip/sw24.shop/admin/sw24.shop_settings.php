<?
// подключим все необходимые файлы:
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php"); // первый общий пролог

//require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/subscribe/include.php"); // инициализация модуля
//require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/subscribe/prolog.php"); // пролог модуля

// подключим языковой файл
IncludeModuleLangFile(__FILE__);

CJSCore::Init(array("jquery"));
$APPLICATION->SetAdditionalCSS("/bitrix/modules/sw24.shop/css/colorpicker.css");
$APPLICATION->AddHeadScript('/bitrix/modules/sw24.shop/js/jcookie.js');
$APPLICATION->AddHeadScript('/bitrix/modules/sw24.shop/js/jscolor.js');
$APPLICATION->AddHeadScript('/bitrix/modules/sw24.shop/js/admin.js');


// получим права доступа текущего пользователя на модуль
$POST_RIGHT = $APPLICATION->GetGroupRight("subscribe");
// если нет прав - отправим к форме авторизации с сообщением об ошибке
if ($POST_RIGHT == "D")
  $APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));

// сформируем список закладок
$aTabs = array(
  array("DIV" => "edit1", "TAB" => GetMessage("main"), "ICON"=>"main_user_edit", "TITLE"=>GetMessage("main")),
  array("DIV" => "edit2", "TAB" => GetMessage("catalog"), "ICON"=>"main_user_edit", "TITLE"=>GetMessage("catalog")),
);
$tabControl = new CAdminTabControl("tabControl", $aTabs);

$ID = intval($ID);		// идентификатор редактируемой записи
$message = null;		// сообщение об ошибке
$bVarsFromForm = false; // флаг "Данные получены с формы", обозначающий, что выводимые данные получены с формы, а не из БД.

// ******************************************************************** //
//                ОБРАБОТКА ИЗМЕНЕНИЙ ФОРМЫ                             //
// ******************************************************************** //

if(
    $REQUEST_METHOD == "POST" // проверка метода вызова страницы
    &&
    ($save!="" || $apply!="") // проверка нажатия кнопок "Сохранить" и "Применить"
    &&
    $POST_RIGHT=="W"          // проверка наличия прав на запись для модуля
    &&
    check_bitrix_sessid()     // проверка идентификатора сессии
)
{
  $rubric = new CRubric;

  // обработка данных формы
  $arFields = Array(
    "ACTIVE"  => ($ACTIVE <> "Y"? "N":"Y"),
    "NAME"    => $NAME,
    "SORT"    => $SORT,
    "DESCRIPTION"  => $DESCRIPTION,
    "LID"    => $LID,
    "AUTO"    =>($AUTO <> "Y"? "N":"Y"),
    "DAYS_OF_MONTH"  => $DAYS_OF_MONTH,
    "DAYS_OF_WEEK"  => (is_array($DAYS_OF_WEEK)?implode(",", $DAYS_OF_WEEK):""),
    "TIMES_OF_DAY"  => $TIMES_OF_DAY,
    "TEMPLATE"  => $TEMPLATE,
    "VISIBLE"  => ($VISIBLE <> "Y"? "N":"Y"),
    "FROM_FIELD"  => $FROM_FIELD,
    "LAST_EXECUTED"  => $LAST_EXECUTED
  );

  // сохранение данных
  if($ID > 0)
  {
    $res = $rubric->Update($ID, $arFields);
  }
  else
  {
    $ID = $rubric->Add($arFields);
    $res = ($ID > 0);
  }

  if($res)
  {
    // если сохранение прошло удачно - перенаправим на новую страницу 
    // (в целях защиты от повторной отправки формы нажатием кнопки "Обновить" в браузере)
    if ($apply != "")
      // если была нажата кнопка "Применить" - отправляем обратно на форму.
      LocalRedirect("/bitrix/admin/rubric_edit.php?ID=".$ID."&mess=ok&lang=".LANG."&".$tabControl->ActiveTabParam());
    else
      // если была нажата кнопка "Сохранить" - отправляем к списку элементов.
      LocalRedirect("/bitrix/admin/rubric_admin.php?lang=".LANG);
  }
  else
  {
    // если в процессе сохранения возникли ошибки - получаем текст ошибки и меняем вышеопределённые переменные
    if($e = $APPLICATION->GetException())
      $message = new CAdminMessage(GetMessage("rub_save_error"), $e);
    $bVarsFromForm = true;
  }
}

// ******************************************************************** //
//                ВЫБОРКА И ПОДГОТОВКА ДАННЫХ ФОРМЫ                     //
// ******************************************************************** //

// значения по умолчанию
$str_SORT          = 100;
$str_ACTIVE        = "Y";
$str_AUTO          = "N";
$str_DAYS_OF_MONTH = "";
$str_DAYS_OF_WEEK  = "";
$str_TIMES_OF_DAY  = "";
$str_VISIBLE       = "Y";
$str_LAST_EXECUTED = ConvertTimeStamp(false, "FULL");
$str_FROM_FIELD    = COption::GetOptionString("subscribe", "default_from");

// выборка данных
if($ID>0)
{
  $rubric = CRubric::GetByID($ID);
  if(!$rubric->ExtractFields("str_"))
    $ID=0;
}

// дополнительная подготовка данных
if($ID>0 && !$message)
  $DAYS_OF_WEEK = explode(",", $str_DAYS_OF_WEEK);
if(!is_array($DAYS_OF_WEEK))
  $DAYS_OF_WEEK = array();

// если данные переданы из формы, инициализируем их
if($bVarsFromForm)
  $DB->InitTableVarsForEdit("b_list_rubric", "", "str_");

// ******************************************************************** //
//                ВЫВОД ФОРМЫ                                           //
// ******************************************************************** //

// установим заголовок страницы
$APPLICATION->SetTitle("SW24SHOP > Настройки");

// не забудем разделить подготовку данных и вывод
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

// конфигурация административного меню
$aMenu = array(
  array(
    "TEXT"=>GetMessage("rub_list"),
    "TITLE"=>GetMessage("rub_list_title"),
    "LINK"=>"rubric_admin.php?lang=".LANG,
    "ICON"=>"btn_list",
  )
);

if($ID>0)
{
  $aMenu[] = array("SEPARATOR"=>"Y");
  $aMenu[] = array(
    "TEXT"=>GetMessage("rub_add"),
    "TITLE"=>GetMessage("rubric_mnu_add"),
    "LINK"=>"rubric_edit.php?lang=".LANG,
    "ICON"=>"btn_new",
  );
  $aMenu[] = array(
    "TEXT"=>GetMessage("rub_delete"),
    "TITLE"=>GetMessage("rubric_mnu_del"),
    "LINK"=>"javascript:if(confirm('".GetMessage("rubric_mnu_del_conf")."'))window.location='rubric_admin.php?ID=".$ID."&action=delete&lang=".LANG."&".bitrix_sessid_get()."';",
    "ICON"=>"btn_delete",
  );
  $aMenu[] = array("SEPARATOR"=>"Y");
  $aMenu[] = array(
    "TEXT"=>GetMessage("rub_check"),
    "TITLE"=>GetMessage("rubric_mnu_check"),
    "LINK"=>"template_test.php?lang=".LANG."&ID=".$ID
  );
}

// создание экземпляра класса административного меню
$context = new CAdminContextMenu($aMenu);

// вывод административного меню
$context->Show();
?>

<?
// если есть сообщения об ошибках или об успешном сохранении - выведем их.
if($_REQUEST["mess"] == "ok" && $ID>0)
  CAdminMessage::ShowMessage(array("MESSAGE"=>GetMessage("rub_saved"), "TYPE"=>"OK"));

if($message)
  echo $message->Show();
elseif($rubric->LAST_ERROR!="")
  CAdminMessage::ShowMessage($rubric->LAST_ERROR);
?>

<?
// далее выводим собственно форму
?>
<form method="POST" Action="<?echo $APPLICATION->GetCurPage()?>" ENCTYPE="multipart/form-data" name="post_form" id="SETTINGS_BODY">
<?// проверка идентификатора сессии ?>
<?echo bitrix_sessid_post();?>
<?
// отобразим заголовки закладок
$tabControl->Begin();
?>
<?
//********************
// первая закладка - форма редактирования параметров рассылки
//********************
$tabControl->BeginNextTab();
?>
  <tr>
    <td>Сайт</td>
    <td><?echo CLang::SelectBox("LID", $str_LID);?></td>
  </tr>
  <tr class="heading">
    <td colspan="2">Настройки цветов<?=$templateName?></td>
  </tr>
  <tr>
    <td width="40%">ЦВЕТОВАЯ СХЕМА</td>
    <td width="60%" class="theme">
	   <?/*<input type="checkbox" name="ACTIVE" value="Y"<?if($str_ACTIVE == "Y") echo " checked"?>>*/?>
	    <input type="hidden" name="theme_color" id="theme_color">
		<input class="color red<?if('red'==$cp_active)echo ' active';?>" value="red" title="Красный">
		<input class="color green<?if('green'==$cp_active)echo ' active';?>" value="green" title="Зеленый">
		<input class="color blue<?if('blue'==$cp_active)echo ' active';?>" value="blue" title="Синий">
		<input class="color jscolor<?if('jscolor'==$cp_active)echo ' active';?>" value="<?if(empty($_COOKIE["jscolor"])) echo 498700; else echo $_COOKIE["jscolor"];?>" title="Пользовательский">
	</td>
  </tr>
  <?/*<tr>
    <td><span class="required">*</span><?echo GetMessage("rub_name")?></td>
    <td><input type="text" name="NAME" value="<?echo $str_NAME;?>" size="30" maxlength="100"></td>
  </tr>
  <tr>
    <td><?echo GetMessage("rub_sort")?></td>
    <td><input type="text" name="SORT" value="<?echo $str_SORT;?>" size="30"></td>
  </tr>
  <tr>
    <td><?echo GetMessage("rub_desc")?></td>
    <td><textarea class="typearea" name="DESCRIPTION" cols="45" rows="5" wrap="VIRTUAL"><?echo $str_DESCRIPTION; ?></textarea></td>
  </tr>
  <tr>
    <td><?echo GetMessage("rub_auto")?></td>
    <td><input type="checkbox" name="AUTO" value="Y"<?if($str_AUTO == "Y") echo " checked"?> OnClick="if(this.checked) tabControl.EnableTab('edit2'); else tabControl.DisableTab('edit2');"></td>
  </tr>*/?>
<?
//********************
// вторая закладка - параметры автоматической генерации рассылки
//********************
$tabControl->BeginNextTab();
?>
  <tr class="heading">
    <td colspan="2">Умный фильтр</td>
  </tr>
  <tr>
    <td width="40%"><span class="required">*</span>11апуйсмай</td>
    <td width="60%">15р1ри13</td>
  </tr>
  <tr>
    <td>р61п13</td>
    <td>тр613п</td>
  </tr>
  <tr>
    <td><?echo GetMessage("rub_dow")?></td>
    <td>
    <table cellspacing=1 cellpadding=0 border=0 class="internal">
    <?  $arDoW = array(
        "1"  => GetMessage("rubric_mon"),
        "2"  => GetMessage("rubric_tue"),
        "3"  => GetMessage("rubric_wed"),
        "4"  => GetMessage("rubric_thu"),
        "5"  => GetMessage("rubric_fri"),
        "6"  => GetMessage("rubric_sat"),
        "7"  => GetMessage("rubric_sun")
      );
    ?>
      <tr class="heading"><?foreach($arDoW as $strVal=>$strDoW):?>
        <td><?=$strDoW?></td>
        <?endforeach;?>
      </tr>
      <tr>
      <?foreach($arDoW as $strVal=>$strDoW):?>
        <td><input type="checkbox" name="DAYS_OF_WEEK[]" value="<?=$strVal?>"<?if(array_search($strVal, $DAYS_OF_WEEK) !== false) echo " checked"?>></td>
      <?endforeach;?>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td><span class="required">*</span><?echo GetMessage("rub_tod")?></td>
    <td><input type="text" name="TIMES_OF_DAY" value="<?echo $str_TIMES_OF_DAY;?>" size="30" maxlength="255"></td>
  </tr>
  <tr class="heading">
    <td colspan="2"><?echo GetMessage("rub_template")?></td>
  </tr>
<?
$arTemplates=CPostingTemplate::GetList();
if(count($arTemplates)>0):
?>
  <tr>
    <td><span class="required">*</span><?echo GetMessage("rub_templates")?></td>
    <td><table>
<?
  $i=0;
  foreach($arTemplates as $strTemplate):
    $arTemplate = CPostingTemplate::GetByID($strTemplate);
?>
    <tr>
      <td valign="top"><input type="radio" id="TEMPLATE<?=$i?>" name="TEMPLATE" value="<?=$arTemplate["PATH"]?>"<?if($str_TEMPLATE==$arTemplate["PATH"]) echo "checked"?>></td>
      <td>
        <label for="TEMPLATE<?=$i?>" title="<?=$arTemplate["DESCRIPTION"]?>"><?=(strlen($arTemplate["NAME"])>0?$arTemplate["NAME"]:GetMessage("rub_no_name"))?></label><br>
        <?if(IsModuleInstalled("fileman")):?>
          <a title="<?=GetMessage("rub_manage")?>" href="/bitrix/admin/fileman_admin.php?path=<?=urlencode("/".$arTemplate["PATH"])?>"><?=$arTemplate["PATH"]?></a>
        <?else:?>
          <?=$arTemplate["PATH"]?>
        <?endif?>
      </td>
    <?$i++?>
    </tr>
  <?endforeach;?>
    </table></td>
  </tr>
<?else:?>
  <tr>
    <td colspan="2"><?=GetMessage("rub_no_templates")?></td>
  </tr>
<?endif?>
  <tr class="heading">
    <td colspan="2"><?echo GetMessage("rub_post_fields")?></td>
  </tr>
  <tr>
    <td><span class="required">*</span><?echo GetMessage("rub_post_fields_from")?></td>
    <td><input type="text" name="FROM_FIELD" value="<?echo $str_FROM_FIELD;?>" size="30" maxlength="255"></td>
  </tr>
<?
// завершение формы - вывод кнопок сохранения изменений
$tabControl->Buttons(
  array(
    "disabled"=>($POST_RIGHT<"W"),
    "back_url"=>"rubric_admin.php?lang=".LANG,
    
  )
);
?>
<input type="hidden" name="lang" value="<?=LANG?>">
<?if($ID>0 && !$bCopy):?>
  <input type="hidden" name="ID" value="<?=$ID?>">
<?endif;?>
<?
// завершаем интерфейс закладок
$tabControl->End();
?>

<?
// дополнительное уведомление об ошибках - вывод иконки около поля, в котором возникла ошибка
$tabControl->ShowWarnings("post_form", $message);
?>

<?
// дополнительно: динамическая блокировка закладки, если требуется.
?>

<?
// информационная подсказка
echo BeginNote();?>
<span class="required">*</span><?echo GetMessage("REQUIRED_FIELDS")?>
<?echo EndNote();?>

<?
// завершение страницы
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>
