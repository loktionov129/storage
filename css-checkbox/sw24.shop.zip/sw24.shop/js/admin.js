$(document).ready( function() {
	$(".theme .color").on("click", function() {
		$("#theme_color").val(this.value);
	});
	$(".theme .jscolor").on("change", function() {
		$("#theme_color").val(this.value);
	});
	console.log("Hello SW24SHOP > Настройки");
});