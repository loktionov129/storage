$(document).ready( function() {
	// add handlers to settings menu
	$("#SWITCH").on("click", function() {
		if ( parseInt($("#SITE_SETTINGS").css("left")) )
		{
			$("#SITE_SETTINGS").animate({left: '0px'}, 300);
			$.setCookie("switch", "open", 30);
			$(".cp_button").show("fast");
		}
		else
		{
			$("#SITE_SETTINGS").animate({left: '-300px'}, 300);
			$.setCookie("switch", "", -1);
			$(".cp_button").hide("slow");
		}
	});
	$(".cp_button").on("click", function() {
	    $(".cp_button.active").removeClass("active");
	    $(this).addClass("active");
	    
	    $("#SETTINGS_BODY>.active").removeClass("active");
	    $("#"+$(this).data("target")).addClass("active");
	});
	$("#SETTINGS_BODY .theme .color").not(".jscolor").on("click", UpdateTheme);
	$("#SETTINGS_BODY .theme .jscolor").on("change", UpdateTheme);
	function UpdateTheme(jscolor)
	{
		jscolor = this.jscolor || this.value;
		$(".theme .color.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("jscolor"))
		{
			document.getElementById("custom_theme").href = "/bitrix/modules/sw24.shop/css/custom/theme.css?COLOR_1="+jscolor+"&COLOR_2="+jscolor;
			$.setCookie("theme_color", "jscolor", 30);
			$.setCookie("jscolor", jscolor, 30);
			$(".feature-item").css("background", colorToRGBA("#"+jscolor));
		}
		else
		{
			document.getElementById("custom_theme").href = "/bitrix/modules/sw24.shop/css/" + jscolor + "/theme.css";
			$.setCookie("theme_color", jscolor, 30);
			$(".feature-item").css("background", colorToRGBA(jscolor));
		}
	}
	$("#SETTINGS_BODY .bg .color").not(".jscolor").on("click", UpdateBg);
	$("#SETTINGS_BODY .bg .jscolor").on("change", UpdateBg);
	function UpdateBg()
	{
		$(".bg .color.active").removeClass("active");
		$(this).addClass("active");
		color = this.jscolor || this.value;
		document.body.style.backgroundColor = "#" + color;
		$.setCookie("bgcolor", color, 30);
	}
	$("#SETTINGS_BODY .menu .color").not(".jscolor").on("click", UpdateMenu);
	$("#SETTINGS_BODY .menu .jscolor").on("change", UpdateMenu);
	function UpdateMenu()
	{
		$(".menu .color.active").removeClass("active");
		$(this).addClass("active");
		color = this.jscolor || this.value;
		$(".header-bottom").css("background", "#" + color);
		$.setCookie("menucolor", color, 30);
	}
	$(".settings_slider").on("change", function() {
		if (this.value == "center")
		{
			$(".main-slide").css("max-width", "1260px");
		}
		else
		{
			$(".main-slide").css("max-width", "100%");
		}
		$.setCookie("main_slide", this.value, 30);
	});
	$("#SETTINGS_BODY .footer a").on("click", function() {
		$("#SETTINGS_BODY .footer a.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("yes"))
		{
			$(".page__footer").css("max-width", "100%");
			$.setCookie("footer", "", -1);
		}
		else
		{
			$(".page__footer").css("max-width", "1260px");
			$.setCookie("footer", "center", 30);
		}
	});
	
	// load user settings from cookie
  	if ($.getCookie("switch") === "open")
	{
	    $("#SITE_SETTINGS").animate({left: '0px'}, 300);
	    $(".cp_button").show("fast");
	}
	if ($.getCookie("menucolor"))
		$(".header-bottom").css("background", "#" + $.getCookie("menucolor"));
	if ($.getCookie("bgcolor"))
		document.body.style.backgroundColor = "#" + $.getCookie("bgcolor");
	
	if ($.getCookie("main_slide") == "center")
		$(".main-slide").css("max-width", "1260px");
	
	if ($.getCookie("theme_color"))
	{
		if ($.getCookie("theme_color") == "jscolor")
			$(".feature-item").css("background", colorToRGBA("#"+$.getCookie("jscolor")));
		else
			$(".feature-item").css("background", colorToRGBA($.getCookie("theme_color")));
	}
	if ($.getCookie("footer") === "center")
		$(".page__footer").css("max-width", "1260px");
});