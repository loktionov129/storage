<?
$MESS['main'] = 'Основные';
$MESS['catalog'] = 'Каталог';