"use strict";
var Observable_1 = require('rxjs/Observable');
var enterZone_1 = require('../../operator/enterZone');
Observable_1.Observable.prototype.enterZone = enterZone_1.enterZone;
