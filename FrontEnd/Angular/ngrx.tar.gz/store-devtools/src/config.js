import { OpaqueToken } from '@angular/core';
export var STORE_DEVTOOLS_CONFIG = new OpaqueToken('@ngrx/devtools Options');
export var INITIAL_OPTIONS = new OpaqueToken('@ngrx/devtools Initial Config');
//# sourceMappingURL=config.js.map