export { StoreDevtoolsModule } from './src/instrument';
export { StoreDevtools } from './src/devtools';
//# sourceMappingURL=index.js.map