import { Action } from '@ngrx/store';
export declare function toPayload(action: Action): any;
