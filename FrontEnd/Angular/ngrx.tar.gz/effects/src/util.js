export function toPayload(action) {
    return action.payload;
}
//# sourceMappingURL=util.js.map