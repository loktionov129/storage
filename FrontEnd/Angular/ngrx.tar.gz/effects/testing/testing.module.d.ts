import { Actions } from '@ngrx/effects';
import { EffectsRunner } from './runner';
export declare function _createActions(runner: EffectsRunner): Actions;
export declare class EffectsTestingModule {
}
