import { ActionReducer } from './reducer';
export declare function combineReducers(reducers: any): ActionReducer<any>;
