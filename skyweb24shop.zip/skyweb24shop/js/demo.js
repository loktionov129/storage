$(document).ready( function() {
	// reset settings to default
	$(".reset_settings").on("click", function() {
		$.setCookie("switch", "", -1);
		$.setCookie("theme_color", "", -1);
		$.setCookie("jscolor", "", -1);
		$.setCookie("bgcolor", "", -1);
		$.setCookie("areacolor", "", -1);
		$.setCookie("menucolor", "", -1);
		$.setCookie("main_slide", "", -1);
		$.setCookie("promo", "", -1);
		$.setCookie("banner1", "", -1);
		$.setCookie("banner2", "", -1);
		$.setCookie("footer", "", -1);
		window.location.reload();
	});
	
	// toggle left settings menu
	$("#SWITCH").on("click", function() {
		if ( parseInt($("#SITE_SETTINGS").css("left")) )
		{
			$("#SITE_SETTINGS").animate({left: '0px'}, 300);
			$.setCookie("switch", "open", 30);
			$(".cp_button").show("fast");
		}
		else
		{
			$("#SITE_SETTINGS").animate({left: '-300px'}, 300);
			$.setCookie("switch", "", -1);
			$(".cp_button").hide("slow");
		}
	});
	
	// rotate cogs
	$("#SWITCH").on("mouseover", "i.fa", function() {
		$(this).addClass("fa-spin");
	});
	$("#SWITCH").on("mouseleave", "i.fa", function() {
		$(this).removeClass("fa-spin");
	});
	
	// switch left menu tabs
	$(".cp_button").on("click", function() {
	    $(".cp_button.active").removeClass("active");
	    $(this).addClass("active");
	    
	    $("#SETTINGS_BODY>.active").removeClass("active");
	    $("#"+$(this).data("target")).addClass("active");
	});
	
	// select input value when click on him
	$(".specific").on("click", function() {
		this.setSelectionRange(0, this.value.length);
	});
	
	// ##########################################################################################
	//
	// COLOR TAB
	//
	// ##########################################################################################
	
	////////////////
	// THEME SECTION
	////////////////
	
	// update theme 
	$("#SETTINGS_BODY .theme .color").not(".jscolor").on("click", UpdateTheme);
	$("#SETTINGS_BODY .theme .jscolor").on("change", UpdateTheme);
	function UpdateTheme(jscolor)
	{
		jscolor = this.jscolor || this.value;
		$(".theme .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".theme .jscolor").addClass("active");
			jscolor = jscolor.replace("#", "");
		}
		else
		{
			$(this).addClass("active");
		}
		
		if ($(this).hasClass("jscolor") || $(this).hasClass("specific"))
		{
			document.getElementById("custom_theme").href = "/bitrix/templates/skyweb24shop/css/custom/theme.css?THEME_COLOR="+jscolor+"&MENU_COLOR=d61d29&BG_COLOR=ffffff&ver"+new Date().getTime();
			$.setCookie("theme_color", "jscolor", 30);
			$.setCookie("jscolor", jscolor, 30);
			$(".theme .specific").val('#' + jscolor);
		}
		else
		{
			document.getElementById("custom_theme").href = "/bitrix/templates/skyweb24shop/css/" + jscolor + "/theme.css?"+new Date().getTime();
			$.setCookie("theme_color", jscolor, 30);
			$(".theme .specific").val(colorToHEX(jscolor));
		}
	}
	
	$(".theme .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".theme .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateTheme.call(this);
	});
	
	// set default value to specific-theme-input
	if ("redgreenblue".indexOf($(".theme .active").val()) == -1)
		$(".theme .specific").val( '#' + $(".theme .active").val() );
	else
		$(".theme .specific").val( colorToHEX($(".theme .active").val()) );
	
	/////////////////////
	// BACKGROUND SECTION
	/////////////////////
	
	// update background
	$("#SETTINGS_BODY .bg .color").not(".jscolor").on("click", UpdateBg);
	$("#SETTINGS_BODY .bg .jscolor").on("change", UpdateBg);
	function UpdateBg()
	{
		color = this.jscolor || this.value;
		$(".bg .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".bg .jscolor").addClass("active");
			color = color.replace("#", "");
		}
		else
		{
			$(this).addClass("active");
		}
		$.setCookie("bgcolor", color, 30);
		
		if(color == "bg1.jpg" || color == "bg2.jpg")
		{
		    BX("body_wrap").style.background = "url('/bitrix/templates/skyweb24shop/images/"+ color +"')";
			$(".bg .specific").val(color);
		}
		else
		{
		    BX("body_wrap").style.background = "#" + color;
			$(".bg .specific").val("#"+color);
		}
	}
	
	$(".bg .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".bg .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateBg.call(this);
	});
		
	// set default value to specific-bg-input
	if ("whitegrey".indexOf($(".bg .active").val()) != -1)
		$(".bg .specific").val( $(".bg .active").val() );
	else if ($(".bg .active").val().indexOf(".") == -1)
		$(".bg .specific").val( '#' + $(".bg .active").val() );
	else
		$(".bg .specific").val( $(".bg .active").val() );
	
	////////////////////
	// WORK AREA SECTION
	////////////////////
	
	// update work area
	$("#SETTINGS_BODY .area .color").not(".jscolor").on("click", UpdateArea);
	$("#SETTINGS_BODY .area .jscolor").on("change", UpdateArea);
	function UpdateArea()
	{
		color = this.jscolor || this.value;
		$(".area .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".area .jscolor").addClass("active");
			color = color.replace("#", "");
		}
		else
		{
			$(this).addClass("active");
		}
		$.setCookie("areacolor", color, 30);
		
		$("main>div.container, .header-middle>div.container").css("background-color", "#" + color);
		$(".area .specific").val("#" + color);
	}
	
	$(".area .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".area .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateArea.call(this);
	});
		
	// set default value to specific-area-input
	if ("whitegrey".indexOf($(".area .active").val()) == -1)
		$(".area .specific").val( '#' + $(".area .active").val() );
	else
		$(".area .specific").val( $(".area .active").val() );
	
	///////////////
	// MENU SECTION
	///////////////
	$("#SETTINGS_BODY .menu .color").not(".jscolor").on("click", UpdateMenu);
	$("#SETTINGS_BODY .menu .jscolor").on("change", UpdateMenu);
	function UpdateMenu()
	{
		color = this.jscolor || this.value;
		$(".menu .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".menu .jscolor").addClass("active");
			color = color.replace("#", "");
		}
		else
		{
			$(this).addClass("active");
		}
		$(".header-bottom").css("background", "#" + color);
		$.setCookie("menucolor", color, 30);
		$(".menu .specific").val("#"+color);
	}
	
	$(".menu .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".menu .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateMenu.call(this);
	});
	
	// set default value to specific-menu-input
	if ("redgreenblue".indexOf($(".menu .active").val()) == -1)
		$(".menu .specific").val( '#' + $(".menu .active").val() );
	else
		$(".menu .specific").val( $(".menu .active").val() );
	
	// ##########################################################################################
	//
	// INDEX TAB
	//
	// ##########################################################################################
	
	/////////////////
	// SLIDER SECTION
	/////////////////
	$(".settings_slider").on("change", function() {
		if (this.value == "center")
		{
			$(".main-slide").css("max-width", "1280px");
			$(".main-slide").css("display", "block");
		}
		else if (this.value == "full")
		{
			$(".main-slide").css("max-width", "100%");
			$(".main-slide").css("display", "block");
		}
		else
		{
			$(".main-slide").css("display", "none");
		}
		$.setCookie("main_slide", this.value, 30);
	});
	
	////////////////
	// PROMO SECTION
	////////////////
	$("#SETTINGS_BODY .promo a").on("click", function() {
		$("#SETTINGS_BODY .promo a.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("yes"))
		{
			$(".features.js-features").css("display", "block");
			$.setCookie("promo", "", -1);
		}
		else
		{
			$(".features.js-features").css("display", "none");
			$.setCookie("promo", "hide", 30);
		}
	});
	
	//////////////////
	// BANNER1 SECTION
	//////////////////
	$("#SETTINGS_BODY .banner1 a").on("click", function() {
		$("#SETTINGS_BODY .banner1 a.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("yes"))
		{
			$(".rennab").css("display", "block");
			$.setCookie("banner1", "", -1);
		}
		else
		{
			$(".rennab").css("display", "none");
			$.setCookie("banner1", "hide", 30);
		}
	});
	
	//////////////////
	// BANNER2 SECTION
	//////////////////
	$("#SETTINGS_BODY .banner2 a").on("click", function() {
		$("#SETTINGS_BODY .banner2 a.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("yes"))
		{
			$(".rennab2").css("display", "block");
			$.setCookie("banner2", "", -1);
		}
		else
		{
			$(".rennab2").css("display", "none");
			$.setCookie("banner2", "hide", 30);
		}
	});
	
	// ##########################################################################################
	//
	// MAIN TAB
	//
	// ##########################################################################################
	
	/////////////////
	// FOOTER SECTION
	/////////////////
	$("#SETTINGS_BODY .footer a").on("click", function() {
		$("#SETTINGS_BODY .footer a.active").removeClass("active");
		$(this).addClass("active");
		if ($(this).hasClass("yes"))
		{
			$(".page__footer").css("max-width", "100%");
			$.setCookie("footer", "", -1);
		}
		else
		{
			$(".page__footer").css("max-width", "1280px");
			$.setCookie("footer", "center", 30);
		}
	});

	// ##########################################################################################
	//
	// CATALOG TAB
	//
	// ##########################################################################################
	
	///////////////////////
	// SMART FILTER SECTION
	///////////////////////
	
	$(".settings_smfilter").on("change", function() {
		if (this.value == 'none')
		{
			 $(".filter-block").css("display", "none");
		}
		else if(this.value == 'close')
		{
			let sm_titles = $(".sidebar .smartfilter>.filter_item>.filter_title.panel-heading");
			$(sm_titles).find(">a").removeClass("is-active").attr("aria-expanded", "false").addClass("collapsed");
			$(sm_titles).next().removeClass("in").css("height", "0").attr("aria-expanded", "false");
			$(".filter-block").css("display", "block");
		}
		else
		{
			let sm_titles = $(".sidebar .smartfilter>.filter_item>.filter_title.panel-heading");
			$(sm_titles).find(">a").addClass("is-active").attr("aria-expanded", "true").removeClass("collapsed");
			$(sm_titles).next().addClass("in").css("height", "auto").attr("aria-expanded", "true");
			$(".filter-block").css("display", "block");
		}
		$.setCookie("smfilter", this.value, 30);
	});
	
	$(".settings_section.item input[type=checkbox]").on("change", function() {
		$( $(this).data("target") ).css("display", (this.checked ? "block" : "none"));
	});
	

	// ##########################################################################################
	//
	// load user settings from cookie
	//
	// ##########################################################################################
	
  	if ($.getCookie("switch") === "open")
	{
	    $("#SITE_SETTINGS").animate({left: '0px'}, 300);
	    $(".cp_button").show("fast");
	}
	if ($.getCookie("menucolor"))
	{
		$(".header-bottom").css("background", "#" + $.getCookie("menucolor"));
	}
	if ($.getCookie("areacolor"))
	{
		$("main>div.container, .header-middle>div.container").css("background", "#" + $.getCookie("areacolor"));
	}
	if ($.getCookie("bgcolor"))
	{
		if($.getCookie("bgcolor") == "bg1.jpg" || $.getCookie("bgcolor") == "bg2.jpg")
		    BX("body_wrap").style.background = "url('/bitrix/templates/skyweb24shop/images/"+ $.getCookie("bgcolor") +"')";
		else
		    BX("body_wrap").style.background = "#" + $.getCookie("bgcolor");
	}
	
	if ($.getCookie("main_slide") == "center")
		$(".main-slide").css("max-width", "1280px");
	else if ($.getCookie("main_slide") == "none")
		$(".main-slide").css("display", "none");
	
	if ($.getCookie("footer") === "center")
		$(".page__footer").css("max-width", "1280px");
	
	if ($.getCookie("promo") === "hide")
		$(".features.js-features").css("display", "none");
	
	if ($.getCookie("banner1") === "hide")
		$(".rennab").css("display", "none");
	
	if ($.getCookie("banner2") === "hide")
		$(".rennab2").css("display", "none");
	
	if ($.getCookie("smfilter") == 'none')
	{
         $(".filter-block").css("display", "none");
	}
	else if($.getCookie("smfilter") == 'close')
	{
		let sm_titles = $(".sidebar .smartfilter>.filter_item>.filter_title.panel-heading");
		$(sm_titles).find(">a").removeClass("is-active").attr("aria-expanded", "false").addClass("collapsed");
		$(sm_titles).next().removeClass("in").css("height", "0").attr("aria-expanded", "false");
	}
	else
	{
		let sm_titles = $(".sidebar .smartfilter>.filter_item>.filter_title.panel-heading");
		$(sm_titles).find(">a").addClass("is-active").attr("aria-expanded", "true").removeClass("collapsed");
		$(sm_titles).next().addClass("in").css("height", "auto").attr("aria-expanded", "true");
	}
});