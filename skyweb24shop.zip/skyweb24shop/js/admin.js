$(document).ready( function() {
	// select input value when click on him
	$(".specific").on("click", function() {
		this.setSelectionRange(0, this.value.length);
	});
	
	// ##########################################################################################
	//
	// COLOR TAB
	//
	// ##########################################################################################
	
	////////////////
	// THEME SECTION
	////////////////
	
	// update theme 
	function UpdateTheme()
	{
		$("#theme_color").val(this.value.replace("#", ""));
		$(".theme .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".theme .jscolor").addClass("active");
		}
		else
		{
			$(this).addClass("active");
			$(".theme .specific").val('#' + colorToHEX(this.value).replace("#",""));
		}
	}
	$(".theme .color").on("click", UpdateTheme);
	$(".theme .jscolor").on("change", UpdateTheme);
	
	$(".theme .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".theme .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateTheme.call(this);
	});
	
	// set default value to specific-theme-input
	if ("redgreenblue".indexOf($(".theme .active").val()) == -1)
		$(".theme .specific").val( '#' + $(".theme .active").val() );
	else
		$(".theme .specific").val( colorToHEX($(".theme .active").val()) );
	
	/////////////////////
	// BACKGROUND SECTION
	/////////////////////
	
	// update background
	function UpdateBg()
	{
		$("#bgcolor").val(this.value);
		$(".bg .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".bg .jscolor").addClass("active");
		}
		else
		{
			$(this).addClass("active");
			$(".bg .specific").val( (this.value.indexOf('.')!==-1) ? this.value : ('#' + colorToHEX(this.value).replace("#","")) );
		}
	}
	$(".bg .color").on("click", UpdateBg);
	$(".bg .jscolor").on("change", UpdateBg);
	
	$(".bg .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".bg .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateBg.call(this);
	});
		
	// set default value to specific-bg-input
	if ("whitegrey".indexOf($(".bg .active").val()) != -1)
		$(".bg .specific").val( $(".bg .active").val() );
	else if ($(".bg .active").val().indexOf(".") == -1)
		$(".bg .specific").val( '#' + $(".bg .active").val() );
	else
		$(".bg .specific").val( $(".bg .active").val() );
	
	////////////////////
	// WORK AREA SECTION
	////////////////////
	
	// update work area
	function UpdateArea()
	{
		$("#areacolor").val(this.value.replace("#",""));
		$(".area .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".area .jscolor").addClass("active");
		}
		else
		{
			$(this).addClass("active");
			$(".area .specific").val('#' + colorToHEX(this.value).replace("#",""));
		}
	}
	$(".area .color").on("click", UpdateArea);
	$(".area .jscolor").on("change", UpdateArea);
	
	$(".area .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".area .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateArea.call(this);
	});
	
	// set default value to specific-area-input
	if ("redgreenblue".indexOf($(".area .active").val()) == -1)
		$(".area .specific").val( '#' + $(".area .active").val() );
	else
		$(".area .specific").val( $(".area .active").val() );
	
	///////////////
	// MENU SECTION
	///////////////
	
	// update menu
	function UpdateMenu()
	{
		$("#menucolor").val(this.value.replace("#",""));
		$(".menu .color.active").removeClass("active");
		if ($(this).hasClass("specific"))
		{
			$(".menu .jscolor").addClass("active");
		}
		else
		{
			$(this).addClass("active");
			$(".menu .specific").val('#' + colorToHEX(this.value).replace("#",""));
		}
	}
	$(".menu .color").on("click", UpdateMenu);
	$(".menu .jscolor").on("change", UpdateMenu);
	
	$(".menu .specific").on("keyup", function() {
		if (!this.value.match(/^#(?:[0-9a-f]{3}){1,2}$/i)) return;
		$(".menu .jscolor").val(this.value.substr(1)).css("background-color", this.value);
		UpdateMenu.call(this);
	});
	
	// set default value to specific-menu-input
	if ("redgreenblue".indexOf($(".menu .active").val()) == -1)
		$(".menu .specific").val( '#' + $(".menu .active").val() );
	else
		$(".menu .specific").val( $(".menu .active").val() );
	
});