<?header('Content-Type: text/css');
function hex2rgba($color, $alpha=1)
{
	list($r, $g, $b) = sscanf($color, "#%02x%02x%02x");
	return "rgba($r, $g, $b, $alpha)";
}
$css = file_get_contents($_SERVER["DOCUMENT_ROOT"].'/bitrix/templates/skyweb24shop/css/custom/source.css');

//parse_str($_SERVER['QUERY_STRING'], $arr);
$search = array('##THEME_COLOR##', '##MENU_COLOR##', '##BG_COLOR##', '##MAIN_SLIDE##', '##PAGE_FOOTER##', '##FEATURE_ITEM##', '##FEATURE_ICON##', '##AREA_COLOR##');
$replace = array();

// Colors:
if (empty($_GET['THEME_COLOR']) || empty($_GET['MENU_COLOR']) || empty($_GET['BG_COLOR']))
	$replace = array('#498700', '#d61d29', '#fff');
else
{
	if ($_GET['BG_COLOR'] == 'bg1.jpg' || $_GET['BG_COLOR'] == 'bg2.jpg')
	    $replace = array('#'.$_GET['THEME_COLOR'], '#'.$_GET['MENU_COLOR'], "url('/bitrix/templates/skyweb24shop/images/".$_GET['BG_COLOR']."')");
	else
		$replace = array('#'.$_GET['THEME_COLOR'], '#'.$_GET['MENU_COLOR'], '#'.$_GET['BG_COLOR']);
}

// Slider:
if (empty($_GET['MAIN_SLIDE']) || $_GET['MAIN_SLIDE'] == 'full') $replace[] = 'max-width:100%';
elseif ($_GET['MAIN_SLIDE'] == 'center') $replace[] = 'max-width:1260px';
else $replace[] = 'display:none';

// Footer:
if (empty($_GET['PAGE_FOOTER'])) $replace[] = '100%';
else $replace[] = '1260px';

// .feature-item
$replace[] = hex2rgba($replace[0], 0.3);

// .feature-icon
$replace[] = hex2rgba($replace[0], 0.7);

// Area color:
if (empty($_GET['AREA_COLOR'])) $replace[] = '#fff';
else $replace[] = '#'.$_GET['AREA_COLOR'];

echo str_replace($search, $replace, $css);

/*
	THEME_COLOR - #498700
	MENU_COLOR  - #d61d29
	BG_COLOR    - #fff
*/
?>