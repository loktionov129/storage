<?php

$bex_d7dull_default_option = array(
    'max_image_size' => '500',
);
