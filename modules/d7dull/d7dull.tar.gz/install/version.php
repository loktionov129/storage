<?php

$arModuleVersion = array(
    'VERSION' 		=> '0.1.1',
    'VERSION_DATE' 	=> '2015-11-10'
);