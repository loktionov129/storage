<?php

$MESS['BEX_D7DULL_MENU_TITLE'] = 'Меню';
$MESS['BEX_D7DULL_SUBMENU_TITLE'] = 'Подменю';