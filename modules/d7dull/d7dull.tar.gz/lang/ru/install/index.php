<?php

$MESS['BEX_D7DULL_MODULE_NAME'] = 'D7-образец';
$MESS['BEX_D7DULL_MODULE_DESCRIPTION'] = 'Модуль-болванка, написанный на новом ядре Битрикса.';
$MESS['BEX_D7DULL_MODULE_PARTNER_NAME'] = 'Битрикс-эксперты';
