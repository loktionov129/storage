<?php

$MESS['BEX_D7DULL_ID'] = 'ID';
$MESS['BEX_D7DULL_NAME'] = 'Название';
$MESS['BEX_D7DULL_NAME_DEFAULT_VALUE'] = 'Безымянный элемент';
$MESS['BEX_D7DULL_IMAGE_SET'] = 'Изображения';
