<?
define("NO_KEEP_STATISTIC", true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

function SendMail()
{
	if(empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
	{
		return "INVALID_EMAIL";
	}
	
	$login = empty($_POST['login']) ? "логин не указан" : $_POST['login'];
	
	$arEventFields = array
	(
		"USER_LOGIN"    => htmlspecialchars($login),
		"EMAIL_TO"		=> $_POST['email'],
	);
	
	if (CEvent::Send("FEEDBACK_FORM", SITE_ID, $arEventFields))
		return "OK";
	return "ERROR";
}

// handle AJAX POST-REQUEST for SendMail()
if (strtoupper($_SERVER['REQUEST_METHOD']) == "POST" && !empty($_GET['AJAX_MODE']) && $_GET['AJAX_MODE'] == 'Y')
{
	$response = SendMail();
	echo $response;
}

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_after.php");
?>