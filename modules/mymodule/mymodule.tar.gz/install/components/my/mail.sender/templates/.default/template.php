<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
CJSCore::Init(array('ajax'));
?>

<h3><?=GetMessage('MS_TITLE')?></h3>
<p id="test-result">&nbsp;</p>
<form action="<?=$templateFolder?>/ajax.php" method="POST" id="test-form">
	<table>
		<tr>
			<td><label for="test-login"><?=GetMessage('YOUR_LOGIN')?>:</label></td>
			<td><input type="text" name="login" id="test-login" value="<?=$arResult["LOGIN"]?>"></td>
		</tr>
		<tr>
			<td><label for="test-email"><?=GetMessage('YOUR_EMAIL')?>:</label></td>
			<td><input type="email" name="email" id="test-email" value="<?=$arResult["EMAIL"]?>" minlength="3" maxlength="64" required></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="<?=GetMessage('MS_BUTTON_SEND')?>"></td>
		</tr>
	</table>
</form>
<script>
BX.ready(function()
{
	document.getElementById("test-form").onsubmit = function()
    {
        var login = document.getElementById("test-login").value;
        var email = document.getElementById("test-email").value;

		BX.ajax({
			url: this.action + '?AJAX_MODE=Y',
			data: {'login': login, 'email': email},
			method: 'POST',
			dataType: 'text/plain',
			timeout: 30,
			async: true,
			processData: true,
			scriptsRunFirst: true,
			emulateOnload: true,
			start: true,
			cache: false,
			onsuccess: function(response)
			{
				if (response == "OK")
				{
					document.getElementById("test-form").style.opacity = "0";
					document.getElementById("test-result").className = "green";
					document.getElementById("test-result").innerHTML = "<?=GetMessage('MS_MSG_SUCCESS')?>";
				}
				else if (response == "INVALID_EMAIL")
				{
					document.getElementById("test-result").className = "red";
					document.getElementById("test-result").innerHTML = "<?=GetMessage('MS_MSG_INVALID_EMAIL')?>";
				}
				else
				{
					document.getElementById("test-result").className = "red";
					document.getElementById("test-result").innerHTML = "<?=GetMessage('MS_MSG_ERROR')?>";
				}
			}
		});
		
        return false;
    };
});
</script>