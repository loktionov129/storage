<?
$MESS ['AUTHOR_NAME_TIP'] = "This value will be displayed in the sender's name field";
$MESS ['EMAIL_FROM_TIP'] = "This value will be displayed in the sender's email field";
$MESS ['MESSAGE_TIP'] = "This text will be in the body of the email sent";
$MESS ['SEND_SUCCESS_TIP'] = "Notification that appears after sending a message";
?>