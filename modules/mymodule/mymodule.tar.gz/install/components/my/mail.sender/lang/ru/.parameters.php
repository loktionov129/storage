<?
$MESS ['MS_AUTHOR_NAME'] = "Имя отправителя";
$MESS ['MS_EMAIL_FROM'] = "E-mail отправителя";
$MESS ['MS_MESSAGE'] = "Текст сообщения";
$MESS ['MS_SEND_SUCCESS'] = "Уведомление при отправке сообщения";
?>