<?
$MESS ['MAILSENDER_SERVICE'] = "Sending mails";
$MESS ['MS_COMPONENT_NAME'] = "Postman";
$MESS ['MS_COMPONENT_DESC'] = "The component displays a form for sending emails";
?>