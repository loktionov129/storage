<?
$MESS["MS_AUTHOR_NAME"] = "Author login";
$MESS["MS_EMAIL_FROM"] = "Author e-mail";
$MESS["MS_MESSAGE"] = "Text message";
$MESS["MS_SEND_SUCCESS"] = "Notification when sending a message";

?>