<?
var_dump("HELLO");
?>
