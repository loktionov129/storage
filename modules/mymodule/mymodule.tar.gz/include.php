<?

require_once('classes/myeventhandler.php');
require_once('classes/CModuleOptions.php');
