<?
var_dump("HqwdELLO");
?>
