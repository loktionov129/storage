<?
$MESS ['MS_TITLE'] = "[TEST] Отправка сообщения";
$MESS ['YOUR_LOGIN'] = "Ваш Логин";
$MESS ['YOUR_EMAIL'] = "Ваш E-mail";
$MESS ['MS_BUTTON_SEND'] = "Отправить!";
$MESS ['MS_MSG_SUCCESS'] = "Сообщение успешно отправлено!";
$MESS ['MS_MSG_INVALID_EMAIL'] = "Ошибка: введён некорректный E-mail!";
$MESS ['MS_MSG_ERROR'] = "Ошибка: Не удалось отправить сообщение!";
?>