<?
$MESS ['MS_TITLE'] = "[TEST] Mail Sending";
$MESS ['YOUR_LOGIN'] = "Your Login";
$MESS ['YOUR_EMAIL'] = "Your E-mail";
$MESS ['MS_BUTTON_SEND'] = "Submit!";
$MESS ['MS_MSG_SUCCESS'] = "Message sent successfully!";
$MESS ['MS_MSG_INVALID_EMAIL'] = "Error: an incorrect E-mail is entered!";
$MESS ['MS_MSG_ERROR'] = "Error: Failed to send message!";
?>