<?
$MESS ['MAILSENDER_SERVICE'] = "Отправка писем";
$MESS ['MS_COMPONENT_NAME'] = "Почтальон";
$MESS ['MS_COMPONENT_DESC'] = "Компонент выводит форму для отправки писем";
?>