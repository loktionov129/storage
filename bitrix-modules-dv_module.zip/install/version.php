<?
$arModuleVersion = array(
"VERSION" => "0.0.1",
"VERSION_DATE" => "2017-05-12 13:17:00");
?>