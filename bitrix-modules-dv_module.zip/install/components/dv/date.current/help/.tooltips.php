<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTooltips = array
(
	"AUTHOR_NAME" => GetMessage("AUTHOR_NAME_TIP"),
    "EMAIL_FROM" => GetMessage("EMAIL_FROM_TIP"),
    "MESSAGE" => GetMessage("MESSAGE_TIP"),
    "SEND_SUCCESS" => GetMessage("SEND_SUCCESS_TIP"),
);
?>