<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arComponentParameters = array(
	/*"GROUPS" => array(
		"SLIDE_SETTINGS" => array("NAME" => GetMessage("ADV_SLIDE_SETTINGS"), "SORT" => "150"),
		"NAV_SETTINGS" => array("NAME" => GetMessage("ADV_NAV_SETTINGS"), "SORT" => "250")
		),*/
	"PARAMETERS" => array(
		"AUTHOR_NAME" => array(
			"NAME" => GetMessage("MS_AUTHOR_NAME"),
			"PARENT" => "BASE",
			"TYPE" => "STRING",
			"DEFAULT" => "admin"
		),
		"EMAIL_FROM" => array(
			"NAME" => GetMessage("MS_EMAIL_FROM"),
			"PARENT" => "BASE",
			"TYPE" => "STRING",
			"DEFAULT" => "no-reply@bitrix.org"
		),
		"MESSAGE" => array(
			"NAME" => GetMessage("MS_MESSAGE"),
			"PARENT" => "BASE",
			"TYPE" => "STRING",
			"DEFAULT" => "Проверка связи."
		),
		"SEND_SUCCESS" => array(
			"NAME" => GetMessage("MS_SEND_SUCCESS"),
			"PARENT" => "BASE",
			"TYPE" => "STRING",
			"DEFAULT" => "Сообщение успешно отправлено!"
		),
		//"CACHE_TIME" => Array("DEFAULT"=>"0"),
	)
);

/*if ($templateProperties['NEED_TEMPLATE'] == 'Y')
{
	$templates = array('-' => GetMessage("ADV_NOT_SELECTED"));
	$arTemplates = CComponentUtil::GetTemplatesList('bitrix:advertising.banner.view');
	if (is_array($arTemplates) && !empty($arTemplates))
	{
		foreach ($arTemplates as $template)
			$templates[$template['NAME']] = $template['NAME'];
	}

	$arComponentParameters['PARAMETERS']['DEFAULT_TEMPLATE'] = array(
		"NAME" => GetMessage("ADV_DEFAULT_TEMPLATE"),
		"PARENT" => "BASE",
		"TYPE" => "LIST",
		"VALUES" => $templates,
		"DEFAULT" => '',
		"ADDITIONAL_VALUES" => "N"
	);

	unset($templateProperties['NEED_TEMPLATE']);
}*/
