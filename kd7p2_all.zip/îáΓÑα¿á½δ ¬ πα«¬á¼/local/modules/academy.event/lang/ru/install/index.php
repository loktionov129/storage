<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["ACADEMY_EVENT_MODULE_NAME"] = "Учебный модуль для курса D7. События";
$MESS["ACADEMY_EVENT_MODULE_DESC"] = "";
$MESS["ACADEMY_EVENT_PARTNER_NAME"] = "Академия Битрикса";
$MESS["ACADEMY_EVENT_PARTNER_URI"] = "http://academy.1c-bitrix.ru/";

$MESS["ACADEMY_EVENT_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";
?>