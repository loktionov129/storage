<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["ACADEMY_D7_MODULE_NOT_INSTALLED"] = "Учебный модуль Академии битрикса не установлен!";