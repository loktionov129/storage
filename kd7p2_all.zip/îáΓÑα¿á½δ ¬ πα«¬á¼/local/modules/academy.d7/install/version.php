<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2015-08-01 00:00:00"
);
?>