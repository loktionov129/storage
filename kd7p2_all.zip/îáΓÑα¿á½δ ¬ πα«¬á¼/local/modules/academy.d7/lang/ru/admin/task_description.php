<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["TASK_NAME_POKOEV_ORM_DENIED"] = "Закрыт";
$MESS["TASK_DESC_POKOEV_ORM_DENIED"] = "";
$MESS["TASK_NAME_POKOEV_ORM_READ"] = "Чтение";
$MESS["TASK_DESC_POKOEV_ORM_READ"] = "";
$MESS["TASK_NAME_POKOEV_ORM_FULL_ACCESS"] = "Полный доступ";
$MESS["TASK_DESC_POKOEV_ORM_FULL_ACCESS"] = "";