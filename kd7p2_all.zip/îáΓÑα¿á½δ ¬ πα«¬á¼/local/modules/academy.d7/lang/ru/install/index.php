<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["ACADEMY_D7_MODULE_NAME"] = "Учебный модуль для курса D7. Создание модуля";
$MESS["ACADEMY_D7_MODULE_DESC"] = "Описание учебного модуля";
$MESS["ACADEMY_D7_PARTNER_NAME"] = "Академия Битрикса";
$MESS["ACADEMY_D7_PARTNER_URI"] = "http://academy.1c-bitrix.ru/";

$MESS["ACADEMY_D7_DENIED"] = "Доступ закрыт";
$MESS["ACADEMY_D7_READ_COMPONENT"] = "Доступ к компонентам";
$MESS["ACADEMY_D7_WRITE_SETTINGS"] = "Изменение настроек модуля";
$MESS["ACADEMY_D7_FULL"] = "Полный доступ";

$MESS["ACADEMY_D7_INSTALL_TITLE"] = "Установка модуля";
$MESS["ACADEMY_D7_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";

#работа с .settings.php
$MESS["ACADEMY_D7_INSTALL_COUNT"] = "Количество установок модуля: ";
$MESS["ACADEMY_D7_UNINSTALL_COUNT"] = "Количество удалений модуля: ";

$MESS["ACADEMY_D7_NO_CACHE"] = 'Внимание, на сайте выключено кеширование!<br>Возможно замедление в работе модуля.';
#работа с .settings.php
?>