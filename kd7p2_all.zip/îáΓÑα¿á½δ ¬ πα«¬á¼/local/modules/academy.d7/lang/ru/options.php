<?php
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */

$MESS["ACADEMY_D7_TAB_SETTINGS"] = "Основные настройки";
$MESS["ACADEMY_D7_FIELD_TEXT_TITLE"] = "Поле типа текст";
$MESS["ACADEMY_D7_FIELD_LINE_TITLE"] = "Поле типа строка";
$MESS["ACADEMY_D7_FIELD_LIST_TITLE"] = "Поле типа список";